 Incident Response Package


At 09:14 on January 14, 2026, an email reached the inbox of
Yassine Ben Salah, a new intern in NeoMek Robotics' R&D department.
By early afternoon, proprietary blueprints for the company's next
generation gripper arm (Gripper X9) had left the network.

You are the DFIR analyst assigned to this case. The help-desk has
handed you everything that was recovered:


Six questions need answers. Work the case end to end: each finding
feeds the next.

Good luck.
