================================================================
 OPERATION EL STAGIER - Severance
 NeoMek Robotics - SOC Case #2026-0141
================================================================

Three weeks after Yassine Ben Salah's last day, the Gripper X9
firmware build server (buildsrv-ci-02) went dark overnight. The
CI pipeline had wiped its working state and a message was left
in the repo. HR wants a name before they call the police.

You have a dump pulled from the build server:

  buildsrv_dump.tar   trigger, encrypted payload, SSH evidence, logs
  firmware.git         the (bare) firmware repository, post-incident

One flag. Worth getting right, not getting fast.

Good luck.
================================================================
